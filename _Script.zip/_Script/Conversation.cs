using System;
using System.Collections;
using System.Collections.Generic;
using _Script;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

public class Conversation : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI textBox;
    [SerializeField] private List<string> dialogue = new();
    [SerializeField] private GameObject conversationUI;
    
    private Queue<string> _dialogue = new();


    private bool conversationStarted = false;

    private bool charInRadius = false;
    // Start is called before the first frame update
    void Start()
    {
        PackDialogue();
        conversationUI.SetActive(false);
    }

    private void PackDialogue()
    {
        foreach (var o in dialogue) _dialogue.Enqueue(o);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.GetComponent<PlayerStats>())
        {
            charInRadius = true;
            if(!conversationStarted)
            {
                conversationStarted = true;
                LoadNextConversation();
            }

            conversationUI.SetActive(true); //show ui
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.GetComponent<PlayerStats>()) // Assuming your character has the tag "Player"
        {
            conversationUI.SetActive(false); //show ui
            charInRadius = false;
        }
    }

    private void LoadNextConversation()
    {
        if (textBox == null) return;
        if(_dialogue.Count>0)
        {
            textBox.SetText(_dialogue.Dequeue());//set text
        }
        else
        {
            Debug.Log("End Dialogue");
            conversationUI.SetActive(false);
        }
    }


    // Update is called once per frame
    void Update()
    {
        if (!charInRadius) return;
        if(conversationStarted)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                LoadNextConversation();
            }
        }
    }
}
