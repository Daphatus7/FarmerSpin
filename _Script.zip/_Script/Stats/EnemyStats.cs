using UnityEngine;

namespace _Script
{
    public class EnemyStats : StatsPawn
    {
        
    }
}