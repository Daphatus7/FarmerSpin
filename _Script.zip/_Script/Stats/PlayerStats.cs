using System;
using System.Collections.Generic;
using MoreMountains.InventoryEngine;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace _Script
{
    public class PlayerStats : StatsPawn
    {
        [SerializeField] private GameObject weaponPrefab;
        private List<SpanningWeapon> weapons = new List<SpanningWeapon>();
        public UnityEvent<int> onSeedChange;
        private InventoryDemoCharacter playerMovement;
        public int killCount = 0;
        private void Awake()
        {
            playerMovement = GetComponent<InventoryDemoCharacter>();
            SpawnWeapon();
        }

        private void Start()
        {
            onSeedChange?.Invoke(_seedAmount);
        }

        public void KillCount()
        {
            killCount ++ ;
        }
        
        private void Update()
        {
            UpdateWeapons();
        }

        private int _seedAmount = 0;
        
        public void AddMoreSeed()
        {
            _seedAmount += 1;
            onSeedChange?.Invoke(_seedAmount);
        }

        public void IncreaseMovementSpeed(float amount)
        {
            playerMovement.CharacterSpeed += amount;
        }
        
        public bool RemoveSeed()
        {
            if (_seedAmount > 0)
            {
                _seedAmount--;
                onSeedChange?.Invoke(_seedAmount);
                return true;
            }

            return false;
        }
        
        public void RestoreHealth(float amount)
        {
            _health += amount;
            if (_health > _healthMax)
            {
                _healthMax = _health;
            }
            onSeedChange?.Invoke(_seedAmount);
        }
        
        [SerializeField] private float velocity = 60f;
        [SerializeField] private float radius = 2.5f;
        [SerializeField] private float angle = 0f;
        public void SpawnWeapon()
        {
            var o = Instantiate(weaponPrefab, transform).GetComponent<SpanningWeapon>();
            o.transform.SetParent(transform, true);
            o.Initialize(gameObject, velocity, radius, angle);
            weapons.Add(o);
        }

        public override void StatsUpdate()
        {
            
            onSeedChange?.Invoke(_seedAmount);
        }

        public void UpdateWeapons()
        {
            foreach (var weapon in weapons)
            {
                weapon.RotateAroundCharacter(); 
            }
        }

        public void IncreaseWeaponDamage(float amount)
        {
            foreach (var weapon in weapons)
            {
                weapon.IncreaseDamage(amount);
            }
        }

        protected override void OnDeath()
        {
            gameObject.GetComponent<InventoryDemoCharacter>().isDead = true;
            Invoke(nameof(LoadLevel), 10f);
        }

        public string levelToLoad = "Level";
        public void LoadLevel()
        {
            SceneManager.LoadScene(levelToLoad);
            Destroy(gameObject);
        }
    }
}