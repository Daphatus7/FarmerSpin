using UnityEngine;
using DamageNumbersPro;

public abstract class StatsPawn : MonoBehaviour
{
    [SerializeField] protected float _health = 100f; public float health => _health;
    [SerializeField] protected float _healthMax = 100f; public float HealthMax => _healthMax;
    [SerializeField] private Team _team = Team.Player;
    public Team Team => _team;
    [SerializeField] private DamageNumber numberPrefab;


    public void RestoreHealth(float amount)
    {
        _health += amount;
    }
    
    private AudioSource audioSource;

    private void Start()
    {
        // Get the AudioSource component attached to the GameObject
        audioSource = GetComponent<AudioSource>();
    }

    public void PlaySoundEffect()
    {
        // Play the sound
        if(audioSource != null && !audioSource.isPlaying)
        {
            audioSource.Play();
        }
    }
    public void TakeDamage(float amount)
    {
        _health = _health - amount;
        DamageNumber(amount);
        if (_health <= 0)
        {
            OnDeath();
        }

        StatsUpdate();
    }

    public virtual void StatsUpdate()
    {
        PlaySoundEffect();
    }
    
    public void DamageNumber(float amount)
    {
        numberPrefab.Spawn(transform.position, amount);
    }

    protected virtual void OnDeath()
    {
        OnDeathEffect();
        Destroy(gameObject);
    }

    protected virtual void OnDeathEffect()
    {
        
    }
    
}

public enum Team
{
    Player,Enemy,Crop
}