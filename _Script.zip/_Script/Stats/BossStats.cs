using UnityEngine;
using UnityEngine.SceneManagement;

namespace _Script
{
    public class BossStats : EnemyStats
    {
        protected override void OnDeathEffect()
        {
            SceneManager.LoadScene("YouWon");
        }
    }
}