namespace _Script
{
    public class CropStats : StatsPawn
    {
        
    }
}