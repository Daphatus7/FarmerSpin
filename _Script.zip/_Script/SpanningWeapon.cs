using System;
using _Script;
using UnityEngine;

public class SpanningWeapon : Weapon
{
    public GameObject center; // Assign your prefab to this in the Inspector

    [SerializeField] private float velocity = 60f;
    [SerializeField] private float radius = 2.5f;
    [SerializeField] private float angle = 0f;
    private DamageArea _damageArea;
    private void Awake()
    {
        _damageArea = GetComponent<DamageArea>();
    }

    public void IncreaseDamage(float amount)
    {
        _damageArea.damageAmount += amount;
    }

    private void Update()
    {
        //RotateAroundCharacter();
    }

    public void Initialize(GameObject center, float velocity, float radius, float angle)
    {
        this.center = center;
        this.velocity = velocity;
        this.radius = radius;
        this.angle = angle;
    }

    public void SetMotion(float velocity, float radius, float angle)
    {
        this.velocity = velocity;
        this.radius = radius;
        this.angle = angle;
    }
    
    
    
    private Vector3 GetSpawnPosition()
    {
        Vector3 mousePosition = Helpers.GetMousePosition();
        return (mousePosition).normalized * radius;
    }
    
    public void RotateAroundCharacter()
    {
        // Convert speed from degrees per second to radians per second
        float speedRadiansPerSecond = velocity * Mathf.Deg2Rad;

        // Update the angle by the rotation speed adjusted by deltaTime
        angle += speedRadiansPerSecond * Time.deltaTime;

        // Ensure angle stays within 0 to 2*PI radians to keep it in a manageable range
        angle %= 2 * Mathf.PI;

        // Calculate the new position
        Vector2 centerPosition = center.transform.position;
        float x = centerPosition.x + radius * Mathf.Cos(angle);
        float y = centerPosition.y + radius * Mathf.Sin(angle);
        Vector2 newPosition = new Vector2(x, y);

        // Update the object's position, ensuring it stays in the desired Z-plane
        transform.position = new Vector3(newPosition.x, newPosition.y, 0f);
        transform.rotation = GetSpawnRotation();
    }
    
    protected Quaternion GetSpawnRotation()
    {
        //Vector3 mousePosition = Helpers.GetMousePosition(); // Make sure this is in world coordinates
        Vector3 direction = transform.position - center.transform.position;

        // Convert the angle to degrees
        float angleInDegrees = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        // Create a rotation Quaternion using Euler angles
        return Quaternion.Euler(0f, 0f, angleInDegrees); // Subtract 90 degrees if forward is up
    }
    
    protected Vector3 GetCorrectedSpawnPosition()
    {
        Vector3 spawnPosition = GetSpawnPosition();
        Vector3 offsetCenter = new ();
        Vector3 direction = (spawnPosition - offsetCenter).normalized; // Normalizing the direction
        float raycastLength = (spawnPosition - offsetCenter).magnitude;
        return spawnPosition;
    }
    
    
}
