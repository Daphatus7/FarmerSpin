using UnityEngine;
using System.Collections;
using _Script;
using Unity.VisualScripting;

public class MusicVolume : MonoBehaviour
{
    protected AudioSource audioSource;

    public GameObject [] EnableList;
    
    private void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerStats>()) // Assuming your character has the tag "Player"
        {
            audioSource.Play();
            EnableObjects();
            ToggleEffect();
        }
    }
    
    public virtual void ToggleEffect()
    {
    }

    public void EnableObjects()
    {
        foreach(var o in EnableList)
        {
            o.SetActive(true);
        }
    }
    
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.GetComponent<PlayerStats>())
        {
            audioSource.Stop();
        }
    }
}