using UnityEngine;

namespace _Script
{
    public class AreanaVolume : MusicVolume
    {
        [SerializeField] protected GameObject spawner;
        private void EnableSpawner()
        {
            spawner.SetActive(true);
        }

        public override void ToggleEffect()
        {
            Invoke(nameof(EnableSpawner), 10f);
        }
    }
}