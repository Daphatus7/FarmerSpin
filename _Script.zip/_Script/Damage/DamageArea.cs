using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Handles damage Detection in the game
/// Uses Damage Check to check if the condition is valid
/// Initialise Damage Checker to get different damage mode
/// </summary>
//[RequireComponent(typeof(CollisionPath))] // Ensures there is a Collider2D component on the GameObject
public class DamageArea : MonoBehaviour
{
    private Collider2D collision;
    //private LayerMask playerLayer = LayerManager.PlayerLayerMask;
    public float damageAmount = 10.0f; 

    private StatsPawn instigator; // namely the player him self;
    
    [SerializeField] private float hitTimer = 0.5f;

    private StopWatch _stopWatch = new(0.5f);

    private bool _allowToAttack = false;
    // Use this for initialization
    void Start()
    {
        collision = GetComponent<Collider2D>();
        instigator = GetComponent<StatsPawn>();
        if (instigator == null)
        {
            instigator = GetComponentInParent<StatsPawn>();
        }
        if (instigator == null)
        {
            instigator = GetComponentInChildren<StatsPawn>();
        }
    }
    private void Update()
    {
        if (_stopWatch.UpdateTimer())
        {
            _allowToAttack = true;
        }
    }
    
    private void OnTriggerStay2D(Collider2D other)
    {
        TryToApplyDamage(other);
    }

    private void TryToApplyDamage(Collider2D other)
    {
        if (_allowToAttack)
        {
            var tar = other.gameObject;
            if (tar.TryGetComponent<StatsPawn>(out var tarStats))
            {
                if (CanDamage(tarStats.Team))
                {
                    tarStats.TakeDamage(damageAmount);
                    _allowToAttack = false;
                    _stopWatch = new StopWatch(hitTimer);
                }

            }
        }
    }

    private bool CanDamage(Team other)
    {
        if (instigator.Team == Team.Player)
        {
            if (other == Team.Enemy)
            {
                return true;
            }
        }
        else if (instigator.Team == Team.Enemy)
        {
            if (instigator.Team != other)
            {
                return true;
            }
        }
        
        return false;
    }

    private void DestroyDamageArea()
    {
        Debug.LogWarning("DestroyDamageArea Need to find a smarter ways");
        Destroy(gameObject);
    }

    #region -Debug-
    /// <summary>
    /// Debug Section
    /// </summary>
    private void OnDrawGizmos()
    {
        // Ensure the collider is retrieved in the case that it's null
        if (!collision)
        {
            collision = GetComponent<Collider2D>();
        }

        if (collision)
        {
            Gizmos.color = Color.red; // Set the color of the Gizmo

            // Check if the collider is a CircleCollider2D and cast it
            if (collision is CircleCollider2D circleCollider)
            {
                // Take local scale into account to get the actual world size of the collider
                float radius = circleCollider.radius * transform.lossyScale.x; // Use lossyScale for world scale

                // The center of the CircleCollider2D is in local space, convert it to world space
                Vector3 colliderWorldCenter = transform.position + (Vector3)circleCollider.offset;

                // Draw the Gizmo with the same radius as the collider
                Gizmos.DrawWireSphere(colliderWorldCenter, radius);
            }
        }
    }
    #endregion 

}


public enum DamageAreaType
{
    SingleTargetOneHit,
    SingleTargetMultipleHit,
    MultipleTargetsOneHit,
    MultipleTargetsMultipleHit
}