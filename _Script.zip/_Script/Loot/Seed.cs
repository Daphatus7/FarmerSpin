using System;
using UnityEngine;

namespace _Script
{
    public class Seed : Loot
    {
        protected override void OnLooting(PlayerStats player)
        {
            player.AddMoreSeed();
        }



    }
}