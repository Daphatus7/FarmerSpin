using UnityEngine;

namespace _Script
{
    public class Speed : Loot
    {
        protected override void OnLooting(PlayerStats player)
        {
            player.IncreaseMovementSpeed(Random.Range(30, 100));
        }
    }
}