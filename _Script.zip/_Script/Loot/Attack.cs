using UnityEngine;

namespace _Script
{
    public class Attack : Loot
    {
        protected override void OnLooting(PlayerStats player)
        {
            player.IncreaseWeaponDamage(Random.Range(25, 50));
        }
    }
}