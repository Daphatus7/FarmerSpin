using UnityEngine;

namespace _Script
{
    public abstract class Loot : MonoBehaviour
    {
        [SerializeField] protected float amount = 10f;

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.GetComponent<PlayerStats>() is PlayerStats player)
            {
                OnLooting(player);
                Destroy(gameObject);
            }
        }

        protected abstract void OnLooting(PlayerStats player);
        
        private void Awake()
        {
            Invoke(nameof(OnSpoiled), 5f);
        }

        private void OnSpoiled()
        {
            Destroy(gameObject);
        }
    }
}