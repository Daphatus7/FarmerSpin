namespace _Script
{
    public class Trap : Loot
    {
        protected override void OnLooting(PlayerStats player)
        {
            player.TakeDamage(amount);
        }
    }
}