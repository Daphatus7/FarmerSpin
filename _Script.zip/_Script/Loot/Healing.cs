using DamageNumbersPro;
using UnityEngine;

namespace _Script
{
    public class Healing : Loot
    {
        [SerializeField] private DamageNumber healingEffect;
        protected override void OnLooting(PlayerStats player)
        {
            player.RestoreHealth(amount);
            DamageNumber(amount);
        }
        
        public void DamageNumber(float amount)
        {
            healingEffect.Spawn(transform.position, amount);
        }
    }
}