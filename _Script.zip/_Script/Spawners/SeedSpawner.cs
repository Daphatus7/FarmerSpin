using UnityEngine;

namespace _Script
{
    public class SeedSpawner :Spawner
    {
        protected override float SpawnTimer()
        {
            return Random.Range(spawnTimer, spawnTimer * 5);
        }
    }
}