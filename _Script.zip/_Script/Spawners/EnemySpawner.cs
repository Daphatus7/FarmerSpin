using UnityEngine;

namespace _Script
{
    public class EnemySpawner : Spawner
    {

        [SerializeField] private GameObject gateToOpen;
        [SerializeField] private GameObject [] appleSpawners;
        
        public int allowToSpawn = 200;
        
        protected override float SpawnTimer()
        {
            spawnTimer -= 0.05f;
            if (spawnTimer < 0.2) return 0.2f;
            return spawnTimer;
        }

        protected override bool ShouldSpawn()
        {   
            if (totalSpawn < allowToSpawn)
            {
                totalSpawn++;
                return true;
            }
            else
            {
                OnGameFinished();
                return false;
            }
        }

        public void OnGameFinished()
        {
            gateToOpen.SetActive(false);
            foreach (var o in appleSpawners)
            {
                o.SetActive(false);   
            }
        }
    }
}