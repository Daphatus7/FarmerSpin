using System;
using UnityEngine;

namespace _Script
{
    public class Spawner : MonoBehaviour
    {
        [SerializeField] private GameObject _enemyPrefab;
        private BoxCollider2D _collider2D;
        [SerializeField] protected float spawnTimer = 1f;
        private StopWatch _stopWatch = new(1f);

        [SerializeField] protected int totalSpawn = 0;
        private void Awake()
        {
            _collider2D = GetComponent<BoxCollider2D>();
        }

        private void Update()
        {
            if (_stopWatch.UpdateTimer())
            {
                SpawnEnemy();
                _stopWatch = new(SpawnTimer());
            }
        }

        protected virtual float SpawnTimer()
        {
            return spawnTimer;
        }

        protected virtual bool ShouldSpawn()
        {
            return true;
        }
        
        private void SpawnEnemy()
        {
            if (!ShouldSpawn())
            {
                Debug.Log("Spawner Stopped");
                return;
            }
            Vector3 spawnPosition = GetRandomPositionInBox();
            var heroInstance = Instantiate(_enemyPrefab);
            heroInstance.transform.position = spawnPosition;
        }
        
        private Vector3 GetRandomPositionInBox()
        {
            var x = UnityEngine.Random.Range(_collider2D.bounds.min.x, _collider2D.bounds.max.x);
            var y = UnityEngine.Random.Range(_collider2D.bounds.min.y, _collider2D.bounds.max.y);
            var z = -2f;
            return new Vector3(x, y, z);
        }
        
        private Vector3 GetSpawnLocation(BoxCollider2D area)
        {
            float x = UnityEngine.Random.Range(area.bounds.min.x, area.bounds.max.x);
            float y = UnityEngine.Random.Range(area.bounds.min.y, area.bounds.max.y);
            float z = -2f;
            return new Vector3(x, y, z);
        }
        
    }
}