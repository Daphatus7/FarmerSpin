using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public float lerpSpeed = 2.0f;

    [SerializeField]private Vector3 offset = new Vector3(0, 1.66f, 0);

    [SerializeField]private GameObject target;



    private bool hasTarget = false;

    public void SetTarget(GameObject tar)
    {
        this.target = tar;
        hasTarget = true;
        offset += transform.position;// + new Vector3(0, 1.66f, 0);
    }

    private void LateUpdate()
    {
        if(target)
        transform.position = Vector3.Lerp(transform.position, target.transform.position, lerpSpeed * Time.deltaTime);
    }
}