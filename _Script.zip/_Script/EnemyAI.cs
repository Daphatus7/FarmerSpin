using System.Collections;
using System.Collections.Generic;
using _Script;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    [SerializeField] private float searchFrequency = 0.25f;
    private GameObject _tar;
    private StopWatch timer = new(0.25f);
    [SerializeField] private float speed = 3f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Search Enemy
        if (!_tar)
        {
            if (timer.UpdateTimer())
            {
                _tar = FindCrops();
                timer = new(searchFrequency);
            }
        }
        else
        {
            MoveTo(_tar);
        }
    }

    private GameObject FindCrops()
    {
        
        var player = FindObjectsOfType<PlayerStats>();
        if (player.Length > 0)
        {
            return player[0].gameObject;
        }
        
        
        var crops = FindObjectsOfType<CropStats>();
    
        // Check if there are any crops in the array
        if (crops.Length > 0)
        {
            // Generate a random index between 0 and the length of the crops array
            int randomIndex = Random.Range(0, crops.Length);
        
            // Use the random index to select a random crop
            CropStats randomCrop = crops[randomIndex];
        
            // Do something with the randomCrop, e.g., debug log its name
            return randomCrop.gameObject;
        }


        return null;
    }

    
    
    private void MoveTo(GameObject tar)
    {
        var tarPosition = tar.transform.position;
        transform.position = Vector3.MoveTowards(transform.position, tarPosition, speed * Time.deltaTime);
    }
}
