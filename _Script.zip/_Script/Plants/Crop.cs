using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

namespace _Script
{
    public class Crop : CropStats
    {

        [SerializeField] private float stopWatchTimer = 1f;
        private StopWatch _timer = new(1f);
        [SerializeField] private List<Sprite> forms = new List<Sprite>();
        private int growCounter = 0;
        private bool grown = false;
        private bool continueToGrow = true;
        [SerializeField] private int fullGrownCounter = 5;

        private Pot _parent;
        public void Initialize(Pot parent)
        {
            _parent = parent;
        }
        
        protected override void OnDeathEffect()
        {
            _parent.CropDestroyed();
        }
        
        private void Update()
        {
            if (_timer.UpdateTimer())
            {
                _timer = new(stopWatchTimer);
                if (!grown)
                {
                    if (growCounter < fullGrownCounter)
                    {
                        growCounter++;
                        Enlarge();
                    }
                    else
                    {
                        growCounter = 0;
                        continueToGrow = false;
                        if (ChangeForm())
                        {
                            grown = true;
                        }
                    }
                }
                else
                {
                    growCounter++;
                    if (growCounter > fullGrownCounter)
                    {
                        growCounter = 0;
                        SpawnLoot();
                    }                
                }
            }
        }

        private void Enlarge()
        {
            if (continueToGrow)
            {
                transform.localScale *= 1.2f;
            }
        }


        private int formCode = 1;
        private bool ChangeForm()
        {
            if (formCode > 2) return true;
            else
            {
                gameObject.GetComponent<SpriteRenderer>().sprite = forms[formCode];
                formCode++;
                return false;
            }
        }

        private void Awake()
        {
        }
        [SerializeField] private GameObject health;
        [SerializeField] private GameObject attack;
        [SerializeField] private GameObject speed;
        private void SpawnLoot()
        {
            int number = Random.Range(1, 7);
            GameObject toSpawn = null;
            if (number == 1)
            {
                toSpawn = health;
            }
            else if(number == 2)
            {
                toSpawn = attack;
            }
            else if(number == 3)
            {
                toSpawn = speed;
            }
            else
            {
                Debug.Log("Spawn not valid");
            }

            if (toSpawn != null)
            {
                Instantiate(toSpawn, transform.position, transform.rotation);
            }
        }
    }
}