using System;
using UnityEngine;

namespace _Script
{
    public class Pot : MonoBehaviour
    {
        private StopWatch _timer = new();
        [SerializeField] private float renewTimer = 5f;
        [SerializeField] private GameObject _cropPrefab;
        private bool seeded = false;

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (seeded) return;
            if (other.GetComponent<PlayerStats>() is PlayerStats player)
            {
                if (player.RemoveSeed())
                {
                    seeded = true;
                    SpawnCrop();
                    //Spawn Plant
                }
            }
        }


        public void CropDestroyed()
        {
            seeded = false;
        }
        
        public void SpawnCrop()
        {
            var crop = Instantiate(_cropPrefab, transform);
            crop.GetComponent<Crop>().Initialize(this);
        }
        
    }
}