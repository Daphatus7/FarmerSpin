public class IGameService
{
        
}