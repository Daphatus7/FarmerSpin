using System;
using _Script;
using UnityEngine;
/// <summary>
/// Nice, easy to understand enum-based game manager. For larger and more complex games, look into
/// state machines. But this will serve just fine for most games.
/// </summary>
public class MPlayerStatsManager : Singleton<MPlayerStatsManager>
{

    public PlayerStats _playerStats;
    protected override void Awake()
    {
    }
}