using System;
using UnityEngine;


public class StopWatch
{
    private float timeInterval = 1f; public float TimeInterval { get { return timeInterval; } }
    private float internalTimer = 0f; public float InternalTimer { get { return internalTimer; } }
    public bool isChecked = false;

    public StopWatch()
    {

    }

    public StopWatch(float timeInterval)
    {
        this.timeInterval = timeInterval;
    }


    /// <summary>
    /// Return true if time has reached
    /// </summary>
    /// <returns></returns>
    public bool UpdateTimer()
    {
        if (isChecked) return false;

        internalTimer += Time.deltaTime;
        if (TimeReached())
        {
            //internalTimer = 0;
            return true;
        }
        return false;
    }

    public bool TimeReached()
    {
        return internalTimer >= timeInterval;
    }


    public void ForceReset()
    {
        internalTimer = 0f;
        isChecked = false;
    }

}

