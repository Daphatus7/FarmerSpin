using UnityEngine;

/// <summary>
/// A static class for general helpful methods
/// </summary>
public static class Helpers 
{
    /// <summary>
    /// Destroy all child objects of this transform (Unintentionally evil sounding).
    /// Use it like so:
    /// <code>
    /// transform.DestroyChildren();
    /// </code>
    /// </summary>
    public static void DestroyChildren(this Transform t) {
        foreach (Transform child in t) Object.Destroy(child.gameObject);
    }

    public static Vector3 GetMousePosition()
    {
        Vector3 screenPosition = Input.mousePosition;
        screenPosition.z = Camera.main.nearClipPlane - Camera.main.transform.position.z; // Set the distance from the camera
        Vector3 worldPosition = Camera.main.ScreenToWorldPoint(screenPosition);
        return new Vector3(worldPosition.x, worldPosition.y, 0);
    }

}