using System;
using _Script;
using UnityEngine;
using UnityEngine.UI;

public class SeedCounter : MonoBehaviour
{
    private Text _text;
    [SerializeField] private PlayerStats _player;
    
    private void Awake()
    {
        _text = GetComponent<Text>();
    }

    private void Start()
    {
        _player.onSeedChange.AddListener(UpdateSeed);
    }

    private void OnDisable()
    {
        _player.onSeedChange.RemoveListener(UpdateSeed);
    }

    public void UpdateSeed(int amount)
    {
        // Ensure _text and _player are not null to avoid NullReferenceException
        if (_text != null && _player != null)
        {
            // Update the UI text element with the amount, current health, and max health
            _text.text = "Seeds: " + amount + "\nHealth: " + _player.health + "/" + _player.HealthMax +"\nDefeated Enemies" + _player.killCount;
        }
    }
}