using UnityEngine;

namespace _Script
{
    public class Weapon : MonoBehaviour
    {
        
    }
}